# Shadow Stickman — Android proje dosyaları

Bu ilk prototip, diğer uygulamaların üzerinde kendi kendine sağa-sola yürüyen küçük bir çubuk adamı ve mor parıltılı kılıcını gösterir. Ekranın kenarında yön değiştirir; karaktere dokununca kısa bir kılıç savurma animasyonu oynar. Parmağınla sürükleyerek yerini de değiştirebilirsin. Android'in kalıcı bildirimli ön plan servisi kullanılır.

## APK oluşturma

Bu çalışma ortamında Android SDK / Gradle derleme araçları bulunmadığı için hazır APK derlenemedi. Kaynak proje Android Studio ile APK'ya dönüştürülebilir:

1. Android Studio'yu bilgisayara kur.
2. `ShadowStickman` klasörünü **Open** ile aç.
3. Gradle eşitlemesinin tamamlanmasını bekle.
4. **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.
5. APK, `app/build/outputs/apk/debug/app-debug.apk` konumunda oluşur.

## Telefona kurulum

1. APK'yı Android telefona aktar ve aç.
2. Uygulamayı başlat.
3. Android ayarlarında **Diğer uygulamaların üzerinde göster** iznini etkinleştir.
4. Uygulamaya geri dönüp **Karakteri başlat** düğmesine bas.
5. Durdurmak için uygulamayı açıp **Karakteri durdur** düğmesine bas.

## Notlar

- Android 8.0 ve üzeri hedeflenmiştir.
- Karakteri parmağınla sürükleyebilirsin; dokununca kılıcını savurur.
- Android pil yönetimi bazı cihazlarda uzun süreli arka plan çalışmasını kısıtlayabilir.
- Karakter ekranda otomatik olarak sağa-sola gezinir; ekranın kenarına geldiğinde yön değiştirir.
