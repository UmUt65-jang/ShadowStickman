package com.shadow.stickman

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager

class StickmanService : Service() {
    private lateinit var windowManager: WindowManager
    private var characterView: StickmanView? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(7, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (characterView == null) {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val view = StickmanView(this)
            val params = WindowManager.LayoutParams(
                dp(104), dp(130),
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.START
                x = dp(24)
                y = dp(220)
            }
            view.onPositionChanged = { x, y ->
                params.x = x
                params.y = y
                try { windowManager.updateViewLayout(view, params) } catch (_: Exception) {}
            }
            try {
                windowManager.addView(view, params)
                characterView = view
            } catch (_: Exception) {
                stopSelf()
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        characterView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        characterView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "shadow_companion",
                "Shadow Stickman",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Ekranda dolaşan karakter servisi" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "shadow_companion") else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Shadow Stickman aktif")
            .setContentText("Karakter ekranında dolaşıyor. Durdurmak için uygulamayı aç.")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()
}
