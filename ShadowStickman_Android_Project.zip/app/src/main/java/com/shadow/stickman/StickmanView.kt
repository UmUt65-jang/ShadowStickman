package com.shadow.stickman

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.abs
import kotlin.math.sin

class StickmanView(context: Context) : View(context) {
    private val density = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        style = Paint.Style.STROKE
    }
    private var phase = 0f
    private var xPos = (24 * density).toInt()
    private var yPos = (220 * density).toInt()
    private var direction = 1
    private var lastAutoStep = 0L
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var lastTap = 0L
    private var swordSwingUntil = 0L
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    var onPositionChanged: ((Int, Int) -> Unit)? = null

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        phase += 0.075f
        val now = System.currentTimeMillis()
        if (!dragging && now - lastAutoStep >= 32L) {
            val maxX = (resources.displayMetrics.widthPixels - width).coerceAtLeast(0)
            xPos += (1.15f * density * direction).toInt().coerceAtLeast(1) * direction
            if (xPos <= 0) { xPos = 0; direction = 1 }
            if (xPos >= maxX) { xPos = maxX; direction = -1 }
            onPositionChanged?.invoke(xPos, yPos)
            lastAutoStep = now
        }
        val bob = sin(phase.toDouble()).toFloat() * 2.2f * density
        val cx = width * 0.48f
        val cy = height * 0.47f + bob
        val s = density

        // Soft, subtle shadow.
        paint.style = Paint.Style.FILL
        paint.color = 0x33000000
        canvas.drawOval(RectF(cx - 17*s, cy + 45*s, cx + 19*s, cy + 51*s), paint)

        // Stick figure: smooth white lines and a dark outline.
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 5.2f * s
        paint.color = 0xFF11131B.toInt()
        drawFigure(canvas, cx, cy, bob, s)
        paint.strokeWidth = 3.1f * s
        paint.color = 0xFFF2F4FA.toInt()
        drawFigure(canvas, cx, cy, bob, s)

        // Small fantasy katana, sized to fit the character's hand.
        drawSword(canvas, cx, cy, bob, s)

        // A tiny glint when the sword is swung.
        if (System.currentTimeMillis() < swordSwingUntil) {
            paint.color = 0xAA9C7BFF.toInt()
            paint.strokeWidth = 2.2f * s
            canvas.drawArc(
                RectF(cx + 3*s, cy - 23*s, cx + 47*s, cy + 24*s),
                205f, 105f, false, paint
            )
        }

        postInvalidateOnAnimation()
    }

    private fun drawFigure(c: Canvas, x: Float, y: Float, bob: Float, s: Float) {
        c.drawCircle(x, y - 28*s, 9*s, paint)
        c.drawLine(x, y - 18*s, x, y + 15*s, paint)
        val walk = sin(phase.toDouble()).toFloat() * 5*s
        c.drawLine(x, y - 9*s, x - 13*s + walk, y + 1*s, paint)
        c.drawLine(x, y - 9*s, x + 12*s - walk, y + 1*s, paint)
        c.drawLine(x, y + 15*s, x - 10*s - walk, y + 37*s, paint)
        c.drawLine(x, y + 15*s, x + 11*s + walk, y + 37*s, paint)
    }

    private fun drawSword(c: Canvas, x: Float, y: Float, bob: Float, s: Float) {
        val swing = if (System.currentTimeMillis() < swordSwingUntil) -0.55f else 0f
        val handX = x + 12*s
        val handY = y + 1*s
        val angle = -0.82f + swing
        val bladeLength = 27*s
        val tipX = handX + kotlin.math.cos(angle) * bladeLength
        val tipY = handY + kotlin.math.sin(angle) * bladeLength

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 4.0f*s
        paint.color = 0xFF33265D.toInt()
        c.drawLine(handX, handY, tipX, tipY, paint)
        paint.strokeWidth = 2.4f*s
        paint.color = 0xFFB9A7FF.toInt()
        c.drawLine(handX, handY, tipX, tipY, paint)

        // Guard and grip.
        val gx = handX + 2*s
        val gy = handY - 2*s
        paint.strokeWidth = 2.5f*s
        paint.color = 0xFFFFD36E.toInt()
        c.drawLine(gx - 4*s, gy + 4*s, gx + 5*s, gy - 4*s, paint)
        paint.color = 0xFF8B6B43.toInt()
        c.drawLine(handX - 2*s, handY + 2*s, handX + 4*s, handY - 3*s, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.rawX
                downY = event.rawY
                lastTouchX = event.rawX
                lastTouchY = event.rawY
                dragging = false
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - downX
                val dy = event.rawY - downY
                if (abs(dx) > slop || abs(dy) > slop) dragging = true
                if (dragging) {
                    xPos = (xPos + (event.rawX - lastTouchX).toInt())
                        .coerceIn(0, (resources.displayMetrics.widthPixels - width).coerceAtLeast(0))
                    yPos = (yPos + (event.rawY - lastTouchY).toInt())
                        .coerceIn(0, (resources.displayMetrics.heightPixels - height).coerceAtLeast(0))
                    onPositionChanged?.invoke(xPos, yPos)
                    lastTouchX = event.rawX
                    lastTouchY = event.rawY
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                if (!dragging) {
                    swordSwingUntil = System.currentTimeMillis() + 650
                    invalidate()
                }
                dragging = false
                return true
            }
        }
        return true
    }
}
