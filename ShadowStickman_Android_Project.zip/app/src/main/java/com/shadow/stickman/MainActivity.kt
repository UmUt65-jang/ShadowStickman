package com.shadow.stickman

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val overlayRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF10131C.toInt())
        }

        val title = TextView(this).apply {
            text = "SHADOW STICKMAN"
            textSize = 25f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "Küçük gezginin ekranında dolaşmasına izin ver.\n\nBaşlatmak için ekran üstü izni gerekir. Karakteri durdurmak için bu uygulamaya geri dön."
            textSize = 16f
            setTextColor(0xFFCFD5E2.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 28)
        }
        val start = Button(this).apply {
            text = "Karakteri başlat"
            setOnClickListener { startCharacter() }
        }
        val stop = Button(this).apply {
            text = "Karakteri durdur"
            setOnClickListener {
                stopService(Intent(this@MainActivity, StickmanService::class.java))
            }
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    private fun startCharacter() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, overlayRequest)
            return
        }
        val service = Intent(this, StickmanService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(service)
        else startService(service)
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == overlayRequest && Settings.canDrawOverlays(this)) startCharacter()
    }
}
