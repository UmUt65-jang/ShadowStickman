plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.shadow.stickman"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.shadow.stickman"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
